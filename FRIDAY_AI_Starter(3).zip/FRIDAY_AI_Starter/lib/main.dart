import 'package:flutter/material.dart';

void main() => runApp(const FridayApp());

const red = Color(0xFFFF465F);

class FridayApp extends StatelessWidget {
  const FridayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FRIDAY AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF09090D),
        colorScheme: const ColorScheme.dark(
          primary: red,
          secondary: Color(0xFFFF6677),
          surface: Color(0xFF17131A),
        ),
        useMaterial3: true,
      ),
      home: const FridayHome(),
    );
  }
}

class FridayHome extends StatelessWidget {
  const FridayHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('FRIDAY AI',
            style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 190,
                height: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    red.withOpacity(.35),
                    const Color(0xFF5A101F).withOpacity(.18),
                    Colors.transparent,
                  ]),
                  border: Border.all(color: red, width: 2),
                  boxShadow: [
                    BoxShadow(color: red.withOpacity(.28), blurRadius: 35, spreadRadius: 8),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.brightness_7, size: 92, color: red),
                ),
              ),
              const SizedBox(height: 26),
              const Text('SYSTEM ONLINE',
                  style: TextStyle(color: Color(0xFFFF6677), letterSpacing: 3)),
              const SizedBox(height: 8),
              const Text('Hello. I am FRIDAY.',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              const Text('Your AI assistant is getting ready.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60)),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => _showInfo(context),
                  icon: const Icon(Icons.mic),
                  label: const Text('VOICE ASSISTANT — COMING NEXT'),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFB91F38),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SecurityLab())),
                  icon: const Icon(Icons.shield_outlined),
                  label: const Text('OPEN ETHICAL HACKER MODE'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: red,
                    side: const BorderSide(color: red),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text('Online • Offline • Multilingual',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  void _showInfo(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('FRIDAY AI'),
        content: const Text(
          'This is the first interface preview. Voice recognition, AI chat, '
          'language detection and device actions will be added in later steps.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }
}

class SecurityLab extends StatelessWidget {
  const SecurityLab({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = [
      (Icons.school_outlined, 'Learn ethical hacking',
          'Beginner lessons about authorization, security basics and responsible testing.'),
      (Icons.language, 'Website security checklist',
          'Review HTTPS, software updates, security headers and account protections manually.'),
      (Icons.wifi, 'Network safety guide',
          'Learn how to secure your own Wi-Fi and recognize unknown devices.'),
      (Icons.bug_report_outlined, 'Vulnerability learning lab',
          'Practice concepts in intentionally vulnerable training labs, not real systems.'),
      (Icons.lock_outline, 'Password strength guide',
          'Learn how to create unique passphrases and use a password manager.'),
      (Icons.description_outlined, 'Create a security report',
          'Record scope, permission, observations, evidence and safe recommendations.'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('ETHICAL HACKER MODE')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF28121A),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: red.withOpacity(.65)),
            ),
            child: const Row(
              children: [
                Icon(Icons.verified_user_outlined, color: red, size: 32),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'SAFE LEARNING LAB\nOnly test devices and websites you own or have explicit permission to assess.',
                    style: TextStyle(height: 1.5),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text('CYBERSECURITY TOOLS',
              style: TextStyle(letterSpacing: 2, color: Color(0xFFFF6677))),
          const SizedBox(height: 10),
          for (final tool in tools)
            Card(
              color: const Color(0xFF17131A),
              child: ListTile(
                leading: Icon(tool.$1, color: red, size: 28),
                title: Text(tool.$2),
                subtitle: Text(tool.$3),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => showDialog<void>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(tool.$2),
                    content: Text(tool.$3),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('CLOSE'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          const SizedBox(height: 12),
          const Text(
            'Build status: interface prototype. Live scanning and integrations are not connected yet.',
            style: TextStyle(color: Colors.white54, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
