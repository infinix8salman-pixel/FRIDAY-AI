# FRIDAY AI — Starter

A Flutter starter for the FRIDAY AI Android assistant.

## Included
- Dark interface with red Arc Reactor-inspired center
- Starter Android APK build workflow for GitHub Actions
- Placeholder for the upcoming voice assistant

## Build on GitHub using an Android phone
1. Create a GitHub repository named `friday-ai`.
2. Upload the contents of this ZIP to the repository root.
3. Open the **Actions** tab and run **Build FRIDAY Android APK**.
4. When the workflow finishes, open its run and download the `friday-ai-apk` artifact.

This is a starter interface, not the complete assistant. Voice activation, AI services,
multilingual speech, offline models, and Android device integrations are not implemented yet.
Never put API keys or passwords in source code.
